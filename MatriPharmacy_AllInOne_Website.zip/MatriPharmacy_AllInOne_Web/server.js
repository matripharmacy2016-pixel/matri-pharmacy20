require('dotenv').config();
const express=require('express'),path=require('path'),crypto=require('crypto');
const bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),Database=require('better-sqlite3');
const app=express(),PORT=process.env.PORT||3000,SECRET=process.env.JWT_SECRET||'CHANGE_ME_LONG_RANDOM_SECRET';
const db=new Database(process.env.DB_FILE||'matri-pharmacy.db'); db.pragma('journal_mode=WAL');
app.use(express.json({limit:'5mb'})); app.use(express.static(path.join(__dirname,'public')));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,mobile TEXT UNIQUE,password TEXT NOT NULL,role TEXT DEFAULT 'owner',active INTEGER DEFAULT 1,verified INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS otp(id INTEGER PRIMARY KEY AUTOINCREMENT,mobile TEXT,code_hash TEXT,purpose TEXT,expires_at INTEGER,used INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),name TEXT,tagline TEXT,address TEXT,phone TEXT,email TEXT,dl TEXT,gstin TEXT,logo TEXT);
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,company TEXT,hsn TEXT,barcode TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS batches(id INTEGER PRIMARY KEY AUTOINCREMENT,medicine_id INTEGER,batch TEXT,expiry TEXT,qty REAL DEFAULT 0,purchase_rate REAL DEFAULT 0,mrp REAL DEFAULT 0,selling_rate REAL DEFAULT 0,gst REAL DEFAULT 0,distributor TEXT);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,mobile TEXT,address TEXT,wallet REAL DEFAULT 0,due REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE,customer_name TEXT,mobile TEXT,address TEXT,doctor_name TEXT,doctor_address TEXT,date TEXT,total REAL,paid REAL,due REAL,payment TEXT,created_by INTEGER);
CREATE TABLE IF NOT EXISTS invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,medicine_id INTEGER,batch_id INTEGER,name TEXT,batch TEXT,expiry TEXT,qty REAL,mrp REAL,discount REAL,gst REAL,total REAL);`);
if(!db.prepare('SELECT id FROM settings WHERE id=1').get()) db.prepare('INSERT INTO settings VALUES(1,?,?,?,?,?,?,?,?)').run('Matri Pharmacy','স্বাস্থ্যই আমাদের অঙ্গীকার','বেড়াচাঁপা, টাকি রোড (এস.বি.আই. অফিসের বিপরীতে), উঃ ২৪ পরগনা','9734327892 / 8250646036','matripharmacy2016@gmail.com','','19AKAPR6670H1ZS','');
const hash=c=>crypto.createHash('sha256').update(c+SECRET).digest('hex');
function otp(m,p){let c=String(Math.floor(100000+Math.random()*900000));db.prepare('INSERT INTO otp(mobile,code_hash,purpose,expires_at) VALUES(?,?,?,?)').run(m,hash(c),p,Date.now()+300000);console.log(`[OTP ${p}] ${m}: ${c}`);}
function verify(m,c,p){let r=db.prepare('SELECT * FROM otp WHERE mobile=? AND purpose=? AND used=0 ORDER BY id DESC LIMIT 1').get(m,p);if(!r||Date.now()>r.expires_at||hash(c)!==r.code_hash)return false;db.prepare('UPDATE otp SET used=1 WHERE id=?').run(r.id);return true}
function auth(req,res,next){try{req.user=jwt.verify((req.headers.authorization||'').replace('Bearer ',''),SECRET);next()}catch(e){res.status(401).json({error:'Login required'})}}
app.get('/health',(q,s)=>s.json({ok:true}));
app.post('/api/register',(q,s)=>{let {name,mobile,password}=q.body;if(!name||!/^[0-9]{10}$/.test(mobile||'')||!password||password.length<8)return s.status(400).json({error:'Name, 10-digit mobile and 8+ character password required'});if(db.prepare('SELECT id FROM users WHERE mobile=?').get(mobile))return s.status(409).json({error:'Mobile already registered'});let r=db.prepare('INSERT INTO users(name,username,mobile,password,role,verified) VALUES(?,?,?,?,?,0)').run(name,mobile,mobile,bcrypt.hashSync(password,12),'owner');otp(mobile,'register');s.json({ok:true,userId:r.lastInsertRowid,message:'OTP generated'});});
app.post('/api/verify-registration',(q,s)=>{if(!verify(q.body.mobile,q.body.otp,'register'))return s.status(400).json({error:'Invalid or expired OTP'});db.prepare('UPDATE users SET verified=1 WHERE mobile=?').run(q.body.mobile);s.json({ok:true})});
app.post('/api/login',(q,s)=>{let u=db.prepare('SELECT * FROM users WHERE username=? OR mobile=?').get(q.body.username,q.body.username);if(!u||!bcrypt.compareSync(q.body.password||'',u.password))return s.status(401).json({error:'Invalid login'});if(!u.verified)return s.status(403).json({error:'Verify your mobile with OTP first'});s.json({token:jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:'12h'}),user:{name:u.name,role:u.role}})});
app.post('/api/forgot/request',(q,s)=>{let u=db.prepare('SELECT id FROM users WHERE mobile=?').get(q.body.mobile);if(u)otp(q.body.mobile,'reset');s.json({ok:true})});
app.post('/api/forgot/reset',(q,s)=>{if(!verify(q.body.mobile,q.body.otp,'reset'))return s.status(400).json({error:'Invalid or expired OTP'});if((q.body.password||'').length<8)return s.status(400).json({error:'Password must be 8+ characters'});db.prepare('UPDATE users SET password=?,verified=1 WHERE mobile=?').run(bcrypt.hashSync(q.body.password,12),q.body.mobile);s.json({ok:true})});
app.get('/api/dashboard',auth,(q,s)=>s.json({sales:db.prepare("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE date(date)=date('now')").get().v,stock:db.prepare('SELECT COALESCE(SUM(qty*mrp),0) v FROM batches').get().v,customers:db.prepare('SELECT COUNT(*) v FROM customers').get().v,due:db.prepare('SELECT COALESCE(SUM(due),0) v FROM customers').get().v}));
app.get('/api/settings',auth,(q,s)=>s.json(db.prepare('SELECT * FROM settings WHERE id=1').get()));
app.get('/api/medicines',auth,(q,s)=>{let x=q.query.q||'';s.json(db.prepare('SELECT * FROM medicines WHERE name LIKE ? OR company LIKE ? LIMIT 100').all('%'+x+'%','%'+x+'%'))});
app.get('/api/customers',auth,(q,s)=>s.json(db.prepare('SELECT * FROM customers ORDER BY name').all()));
app.get('*',(q,s)=>s.sendFile(path.join(__dirname,'public/index.html'))); app.listen(PORT,'0.0.0.0',()=>console.log('Matri Pharmacy ERP on '+PORT));
