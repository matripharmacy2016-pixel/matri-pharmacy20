# Matri Pharmacy All-in-One Website
Web-only responsive ERP. No Android app required.
Includes protected login, registration, OTP verification/reset flows, dashboard, medicines, customers and cloud-ready Node/SQLite backend.
IMPORTANT: real SMS OTP requires an SMS provider/API; the current fallback prints OTP to server logs and must not be used as the production OTP delivery method.
Start: npm install && npm start
